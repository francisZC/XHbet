# jquery-on-off-switch
JQuery based on-off switch for websites
